using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*public interface IWeaponData
{
    int NumberOfAttacks { get; }
    float ReInputTime { get; }
    float[] MovementSpeed { get; }
    float[] AttackDamage { get; }

    Vector2 KnockbackAngle { get; }
    float KnockbackStrength { get; }
}
*/