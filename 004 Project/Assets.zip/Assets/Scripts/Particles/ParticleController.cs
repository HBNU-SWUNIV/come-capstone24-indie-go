using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleController : MonoBehaviour
{
    public void Update()
    {
        
    }
    public void FinishAnim()
    {
        Destroy(gameObject);
    }
}
