using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "newHitStateData", menuName = "Data/State Data/Hit State")]

public class D_HitState
{

}
