using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Use_Effect : ScriptableObject
{
    public abstract bool ExecuteRole();
    
}
