using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemySpawner : MonoBehaviour
{
    public GameObject[] monsterPrefabs;
    public GameObject healthBarPrefab;

    private int selectedMonsterIndex = -1;  // 기본값을 유효하지 않은 값으로 설정
    private Element selectedElement = Element.None;
    private int selectedElementLevel = 1;

    public Button[] monsterButtons;
    public Button[] elementButtons;
    public Button[] elementLevelButtons;
    public Button spawnButton;

    private Color activeColor = Color.green;
    private Color inactiveColor = Color.white;

    void Start()
    {

        for (int i = 0; i < monsterButtons.Length; i++)
        {
            int index = i;  // 클로저 문제를 피하기 위해 지역 변수로 선언
            monsterButtons[i].onClick.AddListener(() => SelectMonster(index));
        }

        // 속성 버튼 클릭 시 속성 선택
        elementButtons[0].onClick.AddListener(() => SelectElement(Element.Fire));
        elementButtons[1].onClick.AddListener(() => SelectElement(Element.Ice));
        elementButtons[2].onClick.AddListener(() => SelectElement(Element.Land));
        elementButtons[3].onClick.AddListener(() => SelectElement(Element.Light));

        // 속성 레벨 버튼 클릭 시 레벨 선택
        elementLevelButtons[0].onClick.AddListener(() => SelectElementLevel(1));
        elementLevelButtons[1].onClick.AddListener(() => SelectElementLevel(2));
        elementLevelButtons[2].onClick.AddListener(() => SelectElementLevel(3));

        // 소환 버튼 클릭 시 몬스터 소환
        spawnButton.onClick.AddListener(SpawnSelectedMonster);
    }

    void Update()
    {
        HandleMonsterSelection();
        HandleElementSelection();
        HandleElementLevelSelection();
        if (Input.GetKeyDown(KeyCode.B))
        {
            SpawnSelectedMonster();
        }
    }

    private void HandleMonsterSelection()
    {
        if (Input.GetKeyDown(KeyCode.Alpha5))
        {
            SelectMonster(0);  // Enemy1
        }
        else if (Input.GetKeyDown(KeyCode.Alpha6))
        {
            SelectMonster(1);  // Goblin
        }
        else if (Input.GetKeyDown(KeyCode.Alpha7))
        {
            SelectMonster(2);  // FlyingEye
        }
        else if (Input.GetKeyDown(KeyCode.Alpha8))
        {
            SelectMonster(3);  // Enemy2
        }
    }

    private void HandleElementSelection()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            SelectElement(Element.Fire);
        }
        else if (Input.GetKeyDown(KeyCode.J))
        {
            SelectElement(Element.Ice);
        }
        else if (Input.GetKeyDown(KeyCode.K))
        {
            SelectElement(Element.Land);
        }
        else if (Input.GetKeyDown(KeyCode.L))
        {
            SelectElement(Element.Light);
        }
    }

    private void HandleElementLevelSelection()
    {
        if (Input.GetKeyDown(KeyCode.U))
        {
            SelectElementLevel(1);
        }
        else if (Input.GetKeyDown(KeyCode.I))
        {
            SelectElementLevel(2);
        }
        else if (Input.GetKeyDown(KeyCode.O))
        {
            SelectElementLevel(3);
        }
    }

    private void SelectMonster(int index)
    {
        selectedMonsterIndex = index;
        Debug.Log($"Selected Monster Index: {index}");

        foreach (Button btn in monsterButtons)
        {
            btn.image.color = inactiveColor;
        }
        if (index >= 0 && index < monsterButtons.Length)
        {
            monsterButtons[index].image.color = activeColor;  // 선택된 버튼을 녹색으로 변경
        }
    }

    private void SelectElement(Element element)
    {
        selectedElement = element;
        Debug.Log($"Selected Element: {element}");

        foreach (Button btn in elementButtons)
        {
            btn.image.color = inactiveColor;
        }

        int elementIndex = (int)element - 1;

        if (elementIndex >= 0 && elementIndex < elementButtons.Length)
        {
            elementButtons[elementIndex].image.color = activeColor;
        }
        else
        {
            Debug.LogError("Element index out of bounds!");
        }
    }
    private void SelectElementLevel(int level)
    {
        selectedElementLevel = level;
        Debug.Log($"Selected Element Level: {level}");

        foreach (Button btn in elementLevelButtons)
        {
            btn.image.color = inactiveColor;
        }
        elementLevelButtons[level - 1].image.color = activeColor;
    }

    private void SpawnSelectedMonster()
    {
        if (selectedMonsterIndex < 0 || selectedMonsterIndex >= monsterPrefabs.Length)
        {
            Debug.Log("유효하지 않은 몬스터 인덱스입니다.");
            return;
        }

        if (selectedElement == Element.None)
        {
            Debug.Log("속성이 선택되지 않았습니다.");
            return;
        }

        GameObject monsterPrefab = monsterPrefabs[selectedMonsterIndex];
        GameObject monsterInstance = Instantiate(monsterPrefab, transform.position, Quaternion.identity);

        // 몬스터의 속성 설정
        EnemyStats enemyStats = monsterInstance.GetComponentInChildren<EnemyStats>();
        if (enemyStats != null)
        {
            enemyStats.ChangeElement(selectedElement, selectedElementLevel);
            Debug.Log($"Spawned Monster with Element: {selectedElement}");
        }
        else
        {
            Debug.LogError("EnemyStats component not found on the monster prefab.");
        }

    }


}