using UnityEngine;

public interface IWeapon
{
    void HandleCollision(Collider2D collision);
}
